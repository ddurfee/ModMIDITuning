/***************************************

ModMIDITuning V1.7
(c) 2014 Dallin S. Durfee
This code may be modified and redistributed
under the MIT license

for gui mode, run
java ModMIDITuning

for command line help run
java ModMIDITuning -h

Source code for Java 1.7

 ***************************************/

/*
  

ToDo

fix notes that don't turn off in pasaglia

When changing tuning reference, tuning, tuning root, tunning freq, redo sequence while playing

Only list .mid or .midi files in file dialog

extended sequencer class?

I->V->IV->VI


Allow user to select midi device
  tried, was causing all kinds of problems

Redo help

Make command line use a=b format
change frequency for A in command line mode!

Add more keystrokes
Record sequence and save to file


Remove dead code
Make things private
Document
Clean up imports

*/


import javax.swing.*; // Timer, JOptionPane
import java.awt.*;//BorderLayout;
import java.awt.event.KeyEvent;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;
import java.awt.Robot;
import javax.imageio.*;
import java.awt.image.BufferedImage;
import javax.swing.border.Border;
import javax.sound.midi.*;
import java.io.*;
import java.lang.Math.*;
import java.util.Arrays;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemListener;
import java.awt.event.ItemEvent;
import java.net.URL;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.awt.event.MouseEvent;
import java.util.ArrayList;
import java.util.List;
import java.text.DecimalFormat;
import java.text.NumberFormat;


public class ModMIDITuning extends JFrame {


    private static long pausePos;
    private static double tuningfrequency;
    //private static long tickpos = 0;
    private static MidiDevice device = null;
    private static Sequence midiIn = null;
    private static Sequence theSequence = null;
    private static Sequencer theSequencer;
    private static MidiChannel[] midichannels = null;
    private static int defaultprogram = 19; // midi 20 (it starts at 1 not zero) - Church Organ
    private static Boolean MajorKey = true;
    private static int middleC = 60;
    private static int chordroot = middleC;
    private static MidiDevice.Info[] midiinfos;
    private static int metaEndTrack = 0x2F; // 47 decimal
    private static int metaCuePoint = 0x07;

    private static int progUseAll = -1;
    private static int progUseFirst = -2;
    private static int progUseSelected = -3;
    private static final String playstring = "Play (alt-x)";
    private static final String stopstring = "Stop and Rewind (alt-x)";
    private static final String pausestring = "Pause (alt-p)";
    private static final String continuestring = "Continue (alt-p)";
    private static int[] progChangeCodes = {progUseAll,progUseFirst,progUseSelected};
    private static String[] progChangeText = {"Apply instrument changes to all MIDI channels","Use first instrument found in file","Use instrument selected above"};
    
    private static String[] notes = {"C","C#","D","D#","E","F","F#","G","G#","A","A#","B"};
    private static String[] Afreqs = {"Standard A:440","European A:442","European A:443","Baroque Pitch A:415","Chorton Pitch A:466","Classical Pitch A:432"};
    private static ArrayList<String> GMPrograms = new ArrayList<String>();
    private static Boolean useGUI = false;
    private static Boolean haderror = false;
    private static String Konami = "uuddlrlrba";
    private static String konamistring = "xxxxxxxxxx";
    private static JPanel jBachChordPanel;
    private static Integer[] bachchordnotes;

    private static String[] intervals = {"unison (DO)","min 2nd","maj 2nd (RE)","min 3rd","maj 3rd (MI)","4th (FA)","aug 4th","5th (SOL)","min 6th","maj 6th (LA)","min 7th","maj 7th (TI)","octave (DO)"};
    private static String[] chords = {"maj","min","aug","dim","7","maj 7","min 7","6","sus 2","sus 4","7 sus 4","2"};
    private static int[][] chordnotes = {{0,4,7},{0,3,7},{0,4,8},{0,3,6},{0,4,7,10},{0,4,7,11},{0,3,7,10},{0,4,7,9},{0,2,7},{0,5,7},{0,5,7,10},{0,4,7,14}};



    private static String versionstring = new String("ModMIDITuning 1.7");
    private static String licensestring = new String("Copyright (c) 2014  Dallin S. Durfee\nPermission to modify and redistribute this software is granted under the MIT License (see License.txt)");
    
    //private static JFrame frame = new JFrame(versionstring);
    private static ImageIcon theIcon, bachIcon;
    private static ModMIDITuning frame = new ModMIDITuning(versionstring);
    private static JTextField jInfile = new JTextField(30);
    private static JComboBox<String> jNotes;
    private static JComboBox<String> jTunings;
    private static JComboBox<Integer> jBendRange;
    private static JCheckBox jBendRangeCommand = new JCheckBox("Write Bend Range Command to MIDI Files");
    private static JComboBox<String> jProgram;
    private static JComboBox<String> jChordRoot;
    private static JButton[] jChordButtons;
    private static JButton jPlay = new JButton(playstring);
    private static JButton jSustain = new JButton("sustain on (.)");
    private static JTuningAdvancedPanel jTuningAdvancedPanel;
    private static Border advancedSettingsBorder;
    private static Border sectionBorder;
    private static JComboBox<Integer> jTransposeAmount;
    private static JProgressBar jMidiProgress;
    private static JTuningSchemePanel jTuningSchemePanel;
    private static JButton jPause;
    private static FocusListener blockKeysFocusListener;
    private static FocusListener blockArrowKeysFocusListener;
    private static JComboBox<String> jChooseFileProgram;
    private static Timer progressTimer;
    private static JButton jGetCuePoint, jGoCuePoint;

    // lowest midi note on the virtual musical keyboard
    private static int lownote = 33;
    // highest midi note on the virtual musical keyboard
    private static int highnote = 88;
    private static KeyboardPanel kbPanel;
    private static Boolean sustain = false;
    // listen to keystrokes - set to false when keyboard used for something
    // else (i.e. we don't want notes played while you type a file name
    private static Boolean catchKeyboard = true; 

    private static String description = "ModMIDITuning allows you to experiment with different tuning methods using the midi synthesis capabilities built into JAVA modern personal computer operating systems.";

    private static String usage = "Starting this progam by double clicking on the jar file, or by running it from the command line with no arguments (java -jar ModMIDITuning.jar), will open up a graphics mode in which you can play notes and intervals on a musical keyboard, play retuned midi files, or save new midi files with different tuning schemes.  There is also a command line mode for advanced users.  For more information on the command line mode, enter java -jar ModMIDITuning.jar -h on the command line.";

    // the text for this string is loaded from "GUIUsage.html"
    private static String guiusage; 
    
    // This is the filename of the file with info for the different tuning schemes.
    // Info on how to add tuning schemes is written in this file
    private static String tuningfilename = new String("ModMIDITuning.tunings"); 
    
    // used to keep track of last file loaded or saved, so that file chooser opens in same directory
    private static String lastfile = new String("");  

    // constructor for the main frame - used to set up keyeventdispatcher to catch keystrokes over
    // entire frame
    private ModMIDITuning(String thestring){
	super(thestring);
	KeyboardFocusManager kbfmanager = KeyboardFocusManager.getCurrentKeyboardFocusManager();
	kbfmanager.addKeyEventDispatcher(new MMTKeyEventDispatcher());
    }

    // process keystrokes
    private class MMTKeyEventDispatcher implements KeyEventDispatcher{
	Boolean bachmanEnabled = false;
	@Override
	public boolean dispatchKeyEvent(KeyEvent e){
	    if(e.getID() == KeyEvent.KEY_PRESSED){
		// if user types escape, return focus to the musical keyboard
		if(e.getKeyCode()==KeyEvent.VK_ESCAPE){
		    kbPanel.requestFocus();
		    catchKeyboard = true;
		    return false;
		}
		// check for alt key combinations
		if((e.getModifiers() & ActionEvent.ALT_MASK) == ActionEvent.ALT_MASK){
		    switch(Character.toLowerCase(e.getKeyChar())){
		    case 's' : jTunings.requestFocus(); break;
		    case 'r' : jNotes.requestFocus(); break;
		    case 'i' : jProgram.requestFocus(); break;
		    case 'g' : jGetCuePoint.doClick(); break;
		    case 'c' : jGoCuePoint.doClick(); break;
		    case 'x' : jPlay.doClick(); break;
		    case 'p' : jPause.doClick(); break;
		    }
		    return false;
		}

		if(!catchKeyboard)
		    return false;
		// use the robot to send another key - this fixes problem where key held down
		// causes automatic repeats of key down and key up events.
		try{
		    Robot robot = new Robot();
		    robot.keyPress(KeyEvent.VK_F12);
		    robot.keyRelease(KeyEvent.VK_F12);
		} catch (Exception ea){}

		switch(e.getKeyCode()){
		case KeyEvent.VK_PERIOD : jSustain.doClick(); break;
		case KeyEvent.VK_ENTER : kbPanel.allOff(); break;
		case KeyEvent.VK_UP : kbPanel.upHalfSteps(12); konamistring = konamistring.substring(1,Konami.length())+"u"; break;
		case KeyEvent.VK_DOWN : kbPanel.downHalfSteps(12); konamistring = konamistring.substring(1,Konami.length())+"d"; break;
		case KeyEvent.VK_LEFT : kbPanel.downHalfStep(); konamistring = konamistring.substring(1,Konami.length())+"l"; break;
		case KeyEvent.VK_RIGHT : kbPanel.upHalfStep(); konamistring = konamistring.substring(1,Konami.length())+"r"; break;
		    
		default :
		    if(Character.toLowerCase(e.getKeyChar()) == 'a')
			konamistring = konamistring.substring(1,Konami.length())+"a";
		    if(Character.toLowerCase(e.getKeyChar()) == 'b')
			konamistring = konamistring.substring(1,Konami.length())+"b"; 
		    for(int i = 0; i<kbPanel.allkeychars.length; i++){
			if(Character.toLowerCase(e.getKeyChar()) == kbPanel.allkeychars[i]){
			    if(sustain){
				kbPanel.toggleNote(kbPanel.allkeynotes[i]);
			    }
			    else{
				kbPanel.playNote(kbPanel.allkeynotes[i]);
			    }
			    break;
			}
		    }
		}
		if(konamistring.equals(Konami)){
		    konamistring = "xxxxxxxxxx";
		    displaymessage("Character \"Bachman\" unlocked!",false,bachIcon);
		    if(!bachmanEnabled){
			bachmanEnabled = true;
			jBachChordPanel.add(new JLabel(bachIcon));
			JButton jBachChord = new JButton("Deploy Bach Chord");
			jBachChord.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
				    kbPanel.allOff();
				    for(int i = 0; i < bachchordnotes.length; i++){
					kbPanel.playNote(chordroot+bachchordnotes[i]);
				    }
				    
				}
			    });
			jBachChordPanel.add(jBachChord);
			//frame.revalidate();
			frame.pack();
			frame.repaint();
		    }
		}
	    } else if(e.getID() == KeyEvent.KEY_RELEASED){
		    for(int i = 0; i<kbPanel.allkeychars.length; i++){
			if(Character.toLowerCase(e.getKeyChar()) == kbPanel.allkeychars[i]){
			    if(!sustain){
				kbPanel.stopNote(kbPanel.allkeynotes[i]);
			    }
			    break;
			}
		    }

	    }
	    return false;
	}
    }

    
    public static void main(String[] args) throws MidiUnavailableException, InvalidMidiDataException, IOException {
	
	// print software name, version, licensing info
	System.out.println(versionstring);
	System.out.println(licensestring);
	System.out.println();
       

	// set default directory to load or save files to the working dir
	lastfile = System.getProperty("user.dir");
	// Make sure that a valid number of arguments were given.  If asking for help, give it.
	// If there are no arguments, start up gui mode.  Otherwise do command line mode
	if(args.length == 0){
	    useGUI = true;
	    // the gui must be built before setupmidi runs
	    // because setupmidi populates the programs (instruments) list
	    // This could be done elsewhere, but in case I ever add a feature
	    // to allow the user to select the midi device, a call to setupmidi
	    // would be able to change the programs list without a call to
	    // another function.
	    // But, because of this, createGUI doesn't display the GUI.
	    // Otherwise it is possible to try to play notes before the
	    // MIDI channels are set up.  So the frame isn't made visible
	    // until setupmidi is run.
	    createGUI();
	    setupmidi();
	    frame.pack();
	    frame.setVisible(true);

	}


	else {
	    // command line mode

	    // if first argument is -h, they want help
	    if(args[0].equals("-h")){
		printHelpAndExit();
	    }
	    // otherwise, the first argument is the infile
	    String infile = args[0];

	    // set up defaults
	    String outfile = null;
	    String tuningscheme = "meantone";
	    int tuningroot = 2;
	    int tuningref = 9;
	    double tuningfreq = 440.0;
	    double bendrange = 2.0;
	    Boolean writeBendrange = true;
	    int instrument = progUseAll;
	    int transpose = 0;
	    
	    int i = 1;
	    // if the second argument doesn't start with -, it's the output filename
	    if(args.length > 1){
		if(!(args[1].startsWith("-"))){
		    i += 1;
		    outfile = args[1];
		}
	    }

	    // lets go through the rest of the arguments
	    while(i < args.length){
		// if the argument doesn't start with -, there's a problem
		if(!(args[i].startsWith("-"))){
		    printUsageAndExit();
		}
		// Arguments come in pairs - type and then value.
		// So there had better be an argument after this one, or there's a problem
		if(i >= args.length - 1){
		    printUsageAndExit();
		}

		// find out what type of argument we have
		switch(args[i]){
		case "-scheme" :
		    tuningscheme = args[i+1]; break;
		case "-root" :
		    try{
			tuningroot = Integer.parseInt(args[i+1]);
		    } catch (NumberFormatException e) {
			printUsageAndExit();
		    }
		    if((tuningroot<0)||(tuningroot>11))
			printUsageAndExit();
		    break;
		case "-refnote" :
		    tuningref = Arrays.asList(notes).indexOf(args[i+1].toUpperCase());
		    if(tuningref < 0)
			printUsageAndExit();
		    break;
		case "-reffreq" :
		    try{
			tuningfreq = Double.parseDouble(args[i+1]);
		    } catch (NumberFormatException e){
			printUsageAndExit();
		    }
		    break;
		case "-bendrange" :
		    try{
			bendrange = Double.parseDouble(args[i+1]);
		    } catch (NumberFormatException e){
			printUsageAndExit();
		    }
		    break;
		case "-writebendrange" :
		    if(args[i+1].toLowerCase() == "true")
			writeBendrange = true;
		    else if(args[i+1].toLowerCase() == "false")
			writeBendrange = false;
		    else
			printUsageAndExit();
		    break;
		case "-instrument" :
		    try{
			instrument = Integer.parseInt(args[i+1]);
		    } catch (NumberFormatException e){
			printUsageAndExit();
		    }
		    if((instrument < progUseFirst)||(instrument > 127))
			printUsageAndExit();
		    break;
		case "-transpose" :
		    try{
			transpose = Integer.parseInt(args[i+1]);
		    } catch (NumberFormatException e){
			printUsageAndExit();
		    }
		    break;
		// if it's not one of these, there is a problem
		default: printUsageAndExit();
		}
		i += 2;
	    }

	    if(outfile == null){
		outfile = getSuggestedFilename(infile, tuningscheme,tuningroot,tuningref,tuningfreq);
	    }
	    makethefile(infile,outfile,tuningroot,tuningscheme,bendrange,writeBendrange,instrument,tuningref,tuningfreq,transpose);
	}  // end of command line mode code	
    }

	/*
	    String outfile = null;
	    String tuningscheme = "meantone";
	    int tuningroot = 2;
	    int tuningref = 9;
	    double tuningfreq = 440.0;
	    double bendrange = 2.0;
	    Boolean writeBendrange = true;
	    int instrument = progUseAll;
	    int transpose = 0;
	*/

    public static void setupmidi() {
	Synthesizer synth = null;

	try{
	    theSequencer = MidiSystem.getSequencer(true);
	    theSequencer.open();
	    //List<Transmitter> tmit = theSequencer.getTransmitters();
	    
	    synth = MidiSystem.getSynthesizer();
	    synth.open();

	    //synthReceiver = tmit.get(0).getReceiver();
	} catch (Exception e) {
	    //System.out.println
	    displayerror("Dang! "+e.toString());
	}



	Instrument[] theinstruments = synth.getAvailableInstruments();
	for(int i=0; i < theinstruments.length; i++){
	    String program = new String(theinstruments[i].toString());
	    if(program.startsWith("Drum")){
		    continue;
	    }
	    if(program.startsWith("Instrument: ")){
		program = program.substring(11);
	    }
	    int pos = program.indexOf("bank");
	    if(pos > 0){
		program = program.substring(0,pos-1);
	    }
	    GMPrograms.add(Integer.toString(i)+": "+program);
	}
	midichannels = synth.getChannels();
	for( String program : GMPrograms ){
	    jProgram.addItem(program);
	}
	jProgram.addItem("Test");
	jProgram.setSelectedIndex(defaultprogram);
	for(int i=0; i < 16; i++){
	    midichannels[i].programChange(defaultprogram);
	}
	changeLiveTuning();

    }

    public static void displaymessage(String thestring){
	displaymessage(thestring,false,theIcon);
    }
    
    public static void displayerror(String thestring){
	displaymessage(thestring,true,theIcon);
    }
    
    public static void displaymessage(String thestring, Boolean iserror, ImageIcon anicon){
	// a simple function to throw up a message
	if(useGUI) {
	    JLabel textArea = new JLabel(thestring);
	    JScrollPane scrollpane = new JScrollPane(textArea,JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED,JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
	    // the scrollpane tries to make itself big enough to hold everything, even if it goes below the screen.
	    // so we'll adjust the vertical dimension to limit how tall it can be.
	    Dimension spSize = scrollpane.getPreferredSize();
	    if(spSize.height > 400)
		spSize.height = 400;
	    // when it adds the scrollbar on the right, it doesn't increase the scrollpane width or reduce the width of the text, and
	    // the text gets cut off.  So I'll add a little buffer space.
	    spSize.width = spSize.width+20;
	    scrollpane.setPreferredSize(spSize);
	    int messagetype = JOptionPane.INFORMATION_MESSAGE;
	    if(iserror)
		messagetype = JOptionPane.ERROR_MESSAGE;
	    JOptionPane.showMessageDialog(frame, scrollpane,versionstring,messagetype,anicon);
	}
	else{
	    System.out.println(thestring);
	}
    }
    

    private static void createGUI() throws  MidiUnavailableException, InvalidMidiDataException, IOException {
	//Set up the GUI.

	// the main frame
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

	// add icon for OS tray
	java.net.URL iconURL = ModMIDITuning.class.getResource("MMTIcon.png");
	theIcon = new ImageIcon(iconURL);
	frame.setIconImage(theIcon.getImage());
	
	// load bach icon and set up bach chord
	iconURL = ModMIDITuning.class.getResource("Bachman.png");
	bachIcon = new ImageIcon(iconURL);
	int bachlowoctave = -3;
	int bachhighoctave = 3;
	bachchordnotes = new Integer[4*(bachhighoctave-bachlowoctave)];
	int bachn = 0;
	int bachoctave = bachlowoctave;
	while(bachn < bachchordnotes.length){
	    bachchordnotes[bachn] = bachoctave*12;
	    bachchordnotes[bachn+1] = bachoctave*12+3;
	    bachchordnotes[bachn+2] = bachoctave*12+6;
	    bachchordnotes[bachn+3] = bachoctave*12+9;
	    bachoctave += 1;
	    bachn += 4;
	}
	    
	// load gui help file
	guiusage = readStringFromJar("GUIUsage.html");
	
	// borders
	advancedSettingsBorder = BorderFactory.createLineBorder(Color.RED);
	sectionBorder = BorderFactory.createLineBorder(Color.BLACK);


	// focus listener
	blockKeysFocusListener = new FocusListener(){
		@Override
		public void focusGained(FocusEvent e){
		    catchKeyboard = false;
		}
		public void focusLost(FocusEvent e){
		    catchKeyboard = true;
		}
	    };
	
	
	// the content pane for the main frame
	final Container contentPane = frame.getContentPane();
	contentPane.setLayout(new BoxLayout(contentPane,BoxLayout.Y_AXIS));



	///////////////////////////////////////////// make main GUI objects
	

	final JPanel topPanel = new JPanel();
	topPanel.setLayout(new BoxLayout(topPanel,BoxLayout.X_AXIS));

	JHelpPanel jHelpPanel = new JHelpPanel();
	
	// create panel to right of the help panel with tuning scheme, root note,
	// and other stuff
	final JPanel jTopRightPanel = new JPanel();
	jTopRightPanel.setLayout(new BoxLayout(jTopRightPanel,BoxLayout.Y_AXIS));

	jTuningSchemePanel = new JTuningSchemePanel();
	
	jTuningAdvancedPanel = new JTuningAdvancedPanel();

	final JPanel jFileSuperPanel = new JPanel(new FlowLayout());
	final JFilePanel jFilePanel = new JFilePanel();

	JChordIntervalPanel jChordIntervalPanel = new JChordIntervalPanel();

	// make the keyboard
	kbPanel = new KeyboardPanel();


	/////////////////////////////////////////////////// add items to panels

	contentPane.add(topPanel);
	topPanel.add(jHelpPanel);
	topPanel.add(Box.createHorizontalGlue()); // slide jHelpPanel to the far left, other stuff to the right
	topPanel.add(jTopRightPanel);

       	jTopRightPanel.add(jTuningSchemePanel);

	JPanel jOptionsPanel = new JPanel(new FlowLayout());
	final JCheckBox showFilePanelCheckBox = new JCheckBox("Show MIDI File Controls");
	showFilePanelCheckBox.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent e){
		    if(showFilePanelCheckBox.isSelected()){
			//int i = getComponentIndex(topPanel,contentPane);
			//contentPane.add(jFilePanel,i+1);
			jFileSuperPanel.add(jFilePanel);
			//frame.revalidate();
			frame.pack();
			frame.repaint();
		    }
		    else{
			jFileSuperPanel.remove(jFilePanel);
			//frame.revalidate();
			frame.pack();
			frame.repaint();
		    }
		}
	    });
	jOptionsPanel.add(showFilePanelCheckBox);

	final JCheckBox advancedcheckbox = new JCheckBox("Show Advanced Options");
	advancedcheckbox.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent e) {
		    if(advancedcheckbox.isSelected()){
			jTopRightPanel.add(jTuningAdvancedPanel);
			jFilePanel.addAdvancedPanel();
			//frame.revalidate();
			frame.pack();
			frame.repaint();
		    }			
		    else{
			jFilePanel.removeAdvancedPanel();
			jTopRightPanel.remove(jTuningAdvancedPanel);
			//frame.revalidate();
			frame.pack();
			frame.repaint();
		    }
		}
	    });
	jOptionsPanel.add(advancedcheckbox);

	jTopRightPanel.add(jOptionsPanel);

	contentPane.add(Box.createRigidArea(new Dimension(10,10)));	

	contentPane.add(jFileSuperPanel);
       
	JPanel keyboardSuperPanel = new JPanel();
	keyboardSuperPanel.setLayout(new BoxLayout(keyboardSuperPanel,BoxLayout.Y_AXIS));
	keyboardSuperPanel.setBorder(sectionBorder);

	keyboardSuperPanel.add(jChordIntervalPanel);
	keyboardSuperPanel.add(kbPanel);
	

	JPanel kbSustainPanel = new JPanel(new FlowLayout());
	JButton jAllOff = new JButton("   ----  ALL NOTES OFF ----    (enter)");
	jAllOff.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent e) {
		    kbPanel.allOff();
		}
	    });
	kbSustainPanel.add(jAllOff);
	sustain = true;
	jSustain.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent e) {
		    if(jSustain.getText() == "sustain on (.)"){
			sustain = false;
			jSustain.setText("sustain off (.)");
		    }
		    else{
			sustain = true;
			jSustain.setText("sustain on (.)");
		    }
		}
	    });
	kbSustainPanel.add(jSustain);
	
	keyboardSuperPanel.add(kbSustainPanel);

	JPanel kbTransposePanel = new JPanel(new FlowLayout());

	JButton jOctaveDown = new JButton("octave down (down)");
	jOctaveDown.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent e) {
		    kbPanel.downHalfSteps(12);
		}
	    });
	kbTransposePanel.add(jOctaveDown);	
	JButton jMoveDown = new JButton("half step down (left)");
	jMoveDown.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent e) {
		    kbPanel.downHalfStep();
		}
	    });
	kbTransposePanel.add(jMoveDown);	
	JButton jMoveUp = new JButton("half step up (right)");
	jMoveUp.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent e) {
		    kbPanel.upHalfStep();
		}
	    });
	kbTransposePanel.add(jMoveUp);
	JButton jOctaveUp = new JButton("octave up (up)");
	jOctaveUp.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent e) {
		    kbPanel.upHalfSteps(12);
		}
	    });
	kbTransposePanel.add(jOctaveUp);
	keyboardSuperPanel.add(kbTransposePanel);

	keyboardSuperPanel.add(Box.createRigidArea(new Dimension(20,20)));

	contentPane.add(keyboardSuperPanel);

	// make panel to display software version and licensing info
	JPanel infoPanel = new JPanel(new FlowLayout());
	contentPane.add(infoPanel);
	JTextArea infotextarea = new JTextArea(licensestring);
	infotextarea.setColumns(70);
	infotextarea.setLineWrap(true);
	infotextarea.setWrapStyleWord(true);
	Font thefont = new Font("Times Roman", Font.ITALIC, 10);
	infotextarea.setFont(thefont);
	infoPanel.add(infotextarea);

	contentPane.add(Box.createRigidArea(new Dimension(2,2)));
	
        //Display the window.

    }

    ////////////////////////////////////////
    ////////////////////////// Various Panels
    //////////////////////////////////////////

    private static class JHelpPanel extends JPanel{
	JHelpPanel(){
	    setLayout(new BoxLayout(this,BoxLayout.X_AXIS));
	    add(new JLabel(theIcon));
	    JButton jHelpButton = new JButton("Help");
	    jHelpButton.setMargin(new Insets(20,30,20,30));
	    jHelpButton.addActionListener(new ActionListener() {
		    public void actionPerformed(ActionEvent e) {
			displaymessage("<html><body style='width:800px;'><h1>"+versionstring+"</h2><h2>"+licensestring+"</h2>"+description+"+"+guiusage+"</body></html>",false,theIcon);
		    }
		});
	    add(jHelpButton);
	}
    }
    
    public static class JTuningSchemePanel extends JPanel{
	JTuningSchemePanel(){
	    setLayout(new FlowLayout());	
	    jNotes = new JComboBox<String>();
	    jNotes.addFocusListener(blockKeysFocusListener);
	    jTunings = new JComboBox<String>();
	    jTunings.addFocusListener(blockKeysFocusListener);


	    // Tuning Schemes
	    JLabel tuningLabel = new JLabel("Tuning Scheme (alt-s):");
	    add(tuningLabel);
	    ArrayList<String> tuninglist = new ArrayList<String>();
	    try{
		tuninglist = gettuninglist();
	    } catch (IOException e) {
		System.exit(1);
	    }
	    while(!tuninglist.isEmpty()){
		jTunings.addItem(tuninglist.remove(0));
	    }
	    jTunings.setSelectedIndex(2);
	    jTunings.addItemListener(new ItemListener(){
		    public void itemStateChanged(ItemEvent e) {
			changeLiveTuning();
		    }
		});
	    add(jTunings);

	    add(Box.createRigidArea(new Dimension(10,1)));

	    // Root Notes
	    add(new JLabel("Tuning Root Note (alt-r):"));
	    for(int i=0; i<notes.length; i++) {
		jNotes.addItem(notes[i]);
	    }
	    jNotes.setSelectedIndex(2);
	    jNotes.addItemListener(new ItemListener(){
		    public void itemStateChanged(ItemEvent e) {
			changeLiveTuning();
		    }
		});
	    add(jNotes);

	    add(Box.createRigidArea(new Dimension(10,1)));

	    // Programs (instruments)
	    add(new JLabel("Instrument (alt-i):"));
	    jProgram = new JComboBox<String>();
	    jProgram.addFocusListener(blockKeysFocusListener);
	    jProgram.addItemListener(new ItemListener(){
		    public void itemStateChanged(ItemEvent e) {
			changeLiveTuning();
		    }
		});
	    add(jProgram);
	}
    }

    public static class JTuningAdvancedPanel extends JPanel {
	private JPanel jTuningNotePanel;
	private JComboBox<String> tuningNotes;
	private JComboBox<String> tuningFreq;
	private Double doubleFreq;
	private Double minfreq,maxfreq;


	JTuningAdvancedPanel() {
	    setLayout(new FlowLayout());
	    jTuningNotePanel = new JPanel(new FlowLayout());
	    jTuningNotePanel.setBorder(advancedSettingsBorder);
	    jTuningNotePanel.add(new JLabel("Tuning Reference"));
	    tuningNotes = new JComboBox<String>();
	    tuningNotes.addFocusListener(blockKeysFocusListener);
	    for(int i=0; i<notes.length; i++) {
		tuningNotes.addItem(notes[i]);
	    }
	    tuningNotes.setSelectedItem("A");
	    
	    setMinMaxFreqs();

	    tuningFreq = new JComboBox<String>();
	    tuningFreq.setEditable(true);
	    // apparently JComboBoxes don't do focus listeners or input verifiers how I would expect.
	    // following code is a workaround
	    tuningFreq.getEditor().getEditorComponent().addFocusListener(blockKeysFocusListener);	  
	    tuningfrequency = 440;
	    ((JTextField) tuningFreq.getEditor().getEditorComponent()).setInputVerifier(new InputVerifier(){
		    public boolean verify(JComponent comp) {
			Double tryfreq = parseFrequency(((JTextField)comp).getText());
			if( tryfreq < 0){
			    displayerror("Please enter a positive number for the frequency");
			    ((JTextField)comp).setText(Double.toString(tuningfrequency));
			    return(false);
			}
			if(( tryfreq < minfreq )||( tryfreq > maxfreq ) ){
			    displayerror("For the selected root note, the frequency must be between "+Double.toString(minfreq)+" Hz and "+Double.toString(maxfreq)+" Hz.  If you are setting the note in a different octave than I was expecting, you might try multiplying or dividing by 2 one or more times to see if you get a frequency in this range.");
			    ((JTextField)comp).setText(Double.toString(tuningfrequency));
			    return(false);
			}
			tuningfrequency = tryfreq;
			((JTextField)comp).setText(Double.toString(tuningfrequency));
			return(true);
		    }
		});
	    tuningFreq.addActionListener(new ActionListener(){
		    public void actionPerformed(ActionEvent e){
			// When changing the list of items in this combo box,
			// we disable it.  That way, when this actionlistener
			// is fired, we don't try to run updateValues
			// which would crash the system because at that moment
			// there is no selection.
			if(tuningFreq.isEnabled())
			    updateValues();
		    }
		});
	    


	    
	    for(int i=0; i<Afreqs.length;i++){
		tuningFreq.addItem(Afreqs[i]);
	    }
	    tuningFreq.setSelectedItem(Integer.toString(440));

	    tuningNotes.addActionListener(new ActionListener(){
		    public void actionPerformed(ActionEvent e){
			String defaultfreq = Double.toString(440.0*Math.pow(2.0,((double)(tuningNotes.getSelectedIndex()-9))/12.0));
			// If we attempt to access the frequency selectio while there are no items, we get a crash. 
			// So the action listener doesn't call the command to update midi settings if tuningFreq
			// is disabled.  That's why I disable it here.
			tuningFreq.setEnabled(false);
			tuningFreq.removeAllItems();
			if(tuningNotes.getSelectedItem()=="A"){
			    for(int i=0; i < Afreqs.length; i++){
				tuningFreq.addItem(Afreqs[i]);
			    }
			    tuningFreq.setSelectedItem("440");
			    //tuningFreq.removeItemAt(0);
			}
			else if(tuningNotes.getSelectedItem() == "C"){
			    tuningFreq.addItem("Standard C:"+defaultfreq);
			    tuningFreq.addItem("\"Scientific\" C:256");
			    tuningFreq.setSelectedItem(defaultfreq);
			    //tuningFreq.removeItemAt(0);
			}
			else{
			    tuningFreq.addItem("Standard "+tuningNotes.getSelectedItem()+":"+defaultfreq);
			    tuningFreq.setSelectedItem(defaultfreq);
			    //tuningFreq.removeItemAt(0);
			}
			tuningFreq.setEnabled(true);
			updateValues();
		    }
		});
	    jTuningNotePanel.add(tuningNotes);

	    jTuningNotePanel.add(tuningFreq);

	    add(jTuningNotePanel);
	}

	public int getRootNote(){
	    return(tuningNotes.getSelectedIndex());
	}
	public Double getFrequency(){
	    return(doubleFreq);
	}

	private void updateValues(){
	    setMinMaxFreqs();
	    doubleFreq = parseFrequency((String)tuningFreq.getSelectedItem());
	    changeLiveTuning();
	}

	private void setMinMaxFreqs(){
	    // assumes a +/- 2 semitone bend range
	    Double stdfreq = 440 * Math.pow(2.0,((double)(tuningNotes.getSelectedIndex()-9))/12.0);
	    minfreq = stdfreq * Math.pow(2.0,-2.0/12.0);
	    maxfreq = stdfreq * Math.pow(2.0,2.0/12.0);
	}

	private Double parseFrequency(String thestring){
	    // parse the frequency string from the frequency combo box
	    // return negative frequency if there is a problem
	    String shortstring;
	    int colonpos = thestring.lastIndexOf(":");
	    if(colonpos >= 0){
		shortstring = thestring.substring(colonpos+1);
	    }
	    else{
		shortstring = thestring;
	    }
	    Double theval;
	    try{
		theval = Double.parseDouble(shortstring);
	    } catch (Exception e){
		theval = -1.0;
	    }
	    return(theval);	   
	} 

	private Boolean isValid(int root,Double freq){
	    return(true);
	}

    }




    public static class JFilePanel extends JPanel {
	private JPanel fileadvancedSuperPanel;
	private JPanel infilePanel;

	JFilePanel(){
	    setLayout(new BoxLayout(this,BoxLayout.Y_AXIS));
	    setBorder(sectionBorder);
	    
	    // make panel to select input file
	    infilePanel = new JPanel(new FlowLayout());
	    add(infilePanel);
	    infilePanel.add(new JLabel("Input File:"));
	    JButton jInfileButton = new JButton("Select File");
	    infilePanel.add(jInfileButton);
	    jInfileButton.addActionListener(new ActionListener() {
		    // code to run when file button is clicked on
		    public void actionPerformed(ActionEvent e) {		    
			catchKeyboard = false;
			JFileChooser fileChooser = new JFileChooser(lastfile);
			fileChooser.setFileSelectionMode(JFileChooser.FILES_ONLY);
			int rVal = fileChooser.showOpenDialog(null);
			if (rVal == JFileChooser.APPROVE_OPTION) {
			    jInfile.setText(fileChooser.getSelectedFile().toString());
			    lastfile = new String(jInfile.getText());
			    try {
				midiIn = MidiSystem.getSequence(new File(lastfile));
			    } catch (Exception ea) {
				displayerror("Error opening midi file "+lastfile+" for reading");
				return;
			    }
			}
			catchKeyboard = true;
		    }
		});
	    jInfile.addFocusListener(blockKeysFocusListener);
	    infilePanel.add(jInfile);
	    	    
	    fileadvancedSuperPanel = new JPanel(new FlowLayout());
	    
	    JPanel fileadvancedPanel = new JPanel();
	    
	    fileadvancedPanel.setLayout(new BoxLayout(fileadvancedPanel,BoxLayout.Y_AXIS));
	    fileadvancedPanel.setBorder(advancedSettingsBorder);
	    fileadvancedSuperPanel.add(fileadvancedPanel);
	    
	    JPanel bendrangeSubPanel = new JPanel(new FlowLayout());
	    
	    fileadvancedPanel.add(bendrangeSubPanel);
	    
	    bendrangeSubPanel.add(new JLabel("Assumed Maximum Bend"));
	    jBendRange = new JComboBox<Integer>();
	    jBendRange = new JComboBox<Integer>();
	    for(int i=1; i<12; i++){
		jBendRange.addItem(i);
	    }
	    jBendRange.setSelectedIndex(1);
	    jBendRange.addFocusListener(blockKeysFocusListener);
	    bendrangeSubPanel.add(jBendRange);
	    
	    jBendRangeCommand.setSelected(true);
	    bendrangeSubPanel.add(jBendRangeCommand);
	    
	    
	    JPanel chooseFileProgramPanel = new JPanel(new FlowLayout());
	    chooseFileProgramPanel.add(new JLabel("Instrument for Saved File / Playback"));
	    jChooseFileProgram = new JComboBox<String>();
	    jChooseFileProgram.addFocusListener(blockKeysFocusListener);
	    for(int i = 0; i < progChangeText.length; i++){
		jChooseFileProgram.addItem(progChangeText[i]);
	    }
	    jChooseFileProgram.addActionListener(new ActionListener(){
		    public void actionPerformed(ActionEvent e){
			changeLiveTuning();
		    }
		});
	    chooseFileProgramPanel.add(jChooseFileProgram);
	    fileadvancedPanel.add(chooseFileProgramPanel);
	    
	    JPanel jTransposePanel = new JPanel(new FlowLayout());
	    jTransposePanel.add(new JLabel("Transpose by (semitones):"));
	    jTransposeAmount = new JComboBox<Integer>();
	    for(int i = -12; i < 13; i++){
		jTransposeAmount.addItem(i);
	    }
	    jTransposeAmount.setSelectedItem(0);
	    jTransposeAmount.addActionListener(new ActionListener(){
		    public void actionPerformed(ActionEvent e){
			changeLiveTuning();
			kbPanel.repaint();
		    }
		});	    
	    jTransposePanel.add(jTransposeAmount);

	    jTransposePanel.add(Box.createRigidArea(new Dimension(30,1)));


	    jGetCuePoint = new JButton("Get CuePoint (alt-g)");
	    jTransposePanel.add(jGetCuePoint);
	    NumberFormat doubleFormat = NumberFormat.getNumberInstance();
	    final JFormattedTextField jCuePoint = new JFormattedTextField(doubleFormat);
	    jCuePoint.addFocusListener(blockKeysFocusListener);
	    jCuePoint.setValue(new Double(0.00000));
	    jCuePoint.setColumns(8);
	    jGetCuePoint.addActionListener(new ActionListener(){
		    public void actionPerformed(ActionEvent e){
			jCuePoint.setValue((((double)theSequencer.getMicrosecondPosition())/((double)1.0e6)));
		    }
		});
	    jTransposePanel.add(jCuePoint);
	    jGoCuePoint = new JButton("Goto CuePoint (alt-c)");
	    jGoCuePoint.addActionListener(new ActionListener(){
		    public void actionPerformed(ActionEvent e){			
			startSequence((long)(((Number)jCuePoint.getValue()).doubleValue()*1.0e6*theSequence.getTickLength()/theSequence.getMicrosecondLength()));
		    }
		});
	    jTransposePanel.add(jGoCuePoint);

	    fileadvancedPanel.add(jTransposePanel);
	    
	    

	    // panel with button to save or play modified midi file
	    JPanel goPanel = new JPanel();
	    goPanel.setLayout(new BoxLayout(goPanel,BoxLayout.X_AXIS));
		
	    add(goPanel);
	    
	    goPanel.add(Box.createRigidArea(new Dimension(20,20)));
	    JButton jGoButton = new JButton("Generate and save re-tuned midi file");
	    goPanel.add(jGoButton);
	    goPanel.add(Box.createRigidArea(new Dimension(30,10)));	

	    //goPanel.add(Box.createHorizontalGlue());
	    
	    jGoButton.addActionListener(new ActionListener() {
		    public void actionPerformed(ActionEvent e) {
			catchKeyboard = false;
			JFileChooser fileChooser = new JFileChooser(lastfile);
			// suggest a new name based on loaded file and tuning selected
			String suggestedfilename = jInfile.getText();
			// get rid of path
			int lastslash = suggestedfilename.lastIndexOf('/');
			if(lastslash >= 0){
			    suggestedfilename = suggestedfilename.substring(lastslash+1);
			}
			lastslash = suggestedfilename.lastIndexOf('\\');
			if(lastslash >=0){
			    suggestedfilename = suggestedfilename.substring(lastslash+1);
			}
			suggestedfilename = getSuggestedFilename(suggestedfilename, (String)jTunings.getSelectedItem(),jNotes.getSelectedIndex(),jTuningAdvancedPanel.getRootNote(),jTuningAdvancedPanel.getFrequency());

			fileChooser.setSelectedFile(new File(suggestedfilename));
			fileChooser.setFileSelectionMode(JFileChooser.FILES_ONLY);
			int rVal = fileChooser.showSaveDialog(null);
			if (rVal == JFileChooser.APPROVE_OPTION) {
			    try{
				// save selected file in string "lastfile"
				lastfile = new String(fileChooser.getSelectedFile().toString());
				// make sure it has the proper extension for a midi file
				if(!lastfile.toLowerCase().endsWith(".mid")){
				    lastfile = new String(lastfile+".mid");
				}
				// make and save the re-tuned midi file			  

				makethefile(jInfile.getText(),lastfile,jNotes.getSelectedIndex(),jTunings.getSelectedItem().toString(),1.0*((Integer)jBendRange.getSelectedItem()),jBendRangeCommand.isSelected(),progChangeCodes[jChooseFileProgram.getSelectedIndex()],jTuningAdvancedPanel.getRootNote(),jTuningAdvancedPanel.getFrequency(),(Integer)jTransposeAmount.getSelectedItem());
				
			    } catch (Exception ee) {}
			}
			catchKeyboard = true;
		    }
		});
	    
	    jMidiProgress = new JProgressBar(0,1);
	    jMidiProgress.addMouseMotionListener(new MouseMotionListener() {
		    public void mouseMoved(MouseEvent e) {
			int x = e.getX();
			int W = jMidiProgress.getWidth();
			long t = theSequencer.getMicrosecondLength();
			DecimalFormat df = new DecimalFormat("#.00");
			jMidiProgress.setToolTipText(df.format(((double)(t*x)/((double)W))/1.0E6)+"s");
		    }
		    public void mouseDragged(MouseEvent e) {
		    }
		});
	    jMidiProgress.addMouseListener(new MouseListener() {
		    public void mouseClicked(MouseEvent e){
			int x = e.getX();
			int W = jMidiProgress.getWidth();
			jMidiProgress.setValue((jMidiProgress.getMaximum()*x)/W);
			startSequence(theSequencer.getTickLength()*x/W);
			//setSequencerTickPosition(theSequencer.getTickLength()*x/W);
			//theSequencer.setTickPosition(theSequencer.getTickLength()*x/W);
		    }
		    
		    public void mousePressed(MouseEvent e){
		    }
		    public void mouseReleased(MouseEvent e){
		    }
		    public void mouseEntered(MouseEvent e){
		    }
		    public void mouseExited(MouseEvent e){
		    }
		});
	    ActionListener updateMidiProgress = new ActionListener() {
		    public void actionPerformed(ActionEvent e){
			jMidiProgress.setValue((int)theSequencer.getMicrosecondPosition()/10000);
			jMidiProgress.repaint();
		    }
		};
	    progressTimer = new Timer(40, updateMidiProgress);
	    jPause = new JButton(pausestring);	
	    jPlay.addActionListener(new ActionListener() {
		    public void actionPerformed(ActionEvent e) {
			if(midiIn != null){
			    if(jPlay.getText()==playstring){
				startSequence(0);
			    }
			    
			    else{
				endSequence(false);
			    }
			}
		    }
		});
	    

	    goPanel.add(jPlay);

	    jPause.addActionListener(new ActionListener(){
		    public void actionPerformed(ActionEvent e){
			if(theSequencer.isRunning()){
			    pausePos = theSequencer.getTickPosition();
			    theSequencer.stop();
			    progressTimer.stop();
			    jPause.setText(continuestring);
			    kbPanel.repaint();
			}
			else{
			    startSequence(pausePos);
			    //theSequencer.start();
			    progressTimer.start();
			    jPause.setText(pausestring);
			}
		    }
		});
	    jPause.setEnabled(false);
	    goPanel.add(jPause);
	    goPanel.add(jMidiProgress);
	    goPanel.add(Box.createRigidArea(new Dimension(20,20)));
	    add(Box.createRigidArea(new Dimension(20,20)));
	}
	
	public void addAdvancedPanel(){
	    int i = getComponentIndex(infilePanel,this);
	    add(fileadvancedSuperPanel,i+1);
	}
	public void removeAdvancedPanel(){
	    remove(fileadvancedSuperPanel);
	}
    }




    public static class JChordIntervalPanel extends JPanel {
	JChordIntervalPanel(){
	    setLayout(new BoxLayout(this,BoxLayout.Y_AXIS));

	    // make buttons to add chords and intervals
	    JPanel chordRootPanel = new JPanel(new FlowLayout());
	    chordRootPanel.add(new JLabel("Insert interval/chord with root"));
	    jChordRoot = new JComboBox<String>();
	    jChordRoot.addFocusListener(blockKeysFocusListener);
	    for(int i=0; i<notes.length; i++) {
		jChordRoot.addItem(notes[i]);
	    }
	    jChordRoot.addItemListener(new ItemListener(){
		    public void itemStateChanged(ItemEvent e) {
			chordroot = jChordRoot.getSelectedIndex()+middleC;
			changeChordLabels();
		    }
		});
	    chordRootPanel.add(jChordRoot);
	    chordRootPanel.add(new JLabel("  (if hot keys are not working, press esc to bring focus to keyboard)"));
	    add(chordRootPanel);
	    
	    JPanel intervalPanel = new JPanel(new FlowLayout());
	    // insert intervals
	    final JButton[] intervalbuttons = new JButton[intervals.length];
	    for(int i=0; i < intervals.length; i++){
		intervalbuttons[i] = new JButton(intervals[i]);
		intervalbuttons[i].setMargin(new Insets(0,0,0,0));
		intervalbuttons[i].addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			    int interval = 0;
			    JButton thisbutton = (JButton) e.getSource();
			    for(int i = 0; i < intervals.length; i++){
				if(thisbutton == intervalbuttons[i]){
				    interval = i;
				    break;
				}
			    }
			    kbPanel.playNote(chordroot);
			    kbPanel.playNote(chordroot+interval);
			}
		    });
		intervalPanel.add(intervalbuttons[i]);
	    }
	    add(intervalPanel);

	    JPanel chordPanel = new JPanel(new FlowLayout());
	    // insert intervals
	    jChordButtons = new JButton[chords.length];
	    for(int i=0; i < chords.length; i++){
		jChordButtons[i] = new JButton();
		jChordButtons[i].setMargin(new Insets(0,0,0,0));
		jChordButtons[i].addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			    kbPanel.allOff();
			    int chord = 0;
			    JButton thisbutton = (JButton) e.getSource();
			    for(int i = 0; i < chords.length; i++){
				if(thisbutton == jChordButtons[i]){
				    chord = i;
				    break;
				}
			    }
			    for(int i = 0; i < chordnotes[chord].length; i++){
				kbPanel.playNote(chordroot+chordnotes[chord][i]);
			    }
			}
		    });
		chordPanel.add(jChordButtons[i]);
	    }
	    changeChordLabels();
	    jBachChordPanel = new JPanel();
	    chordPanel.add(jBachChordPanel);

	    add(chordPanel);
	}
    }

    ////////////////////////////////////////////////////
    ///////////////////////////////////////////////////


    public static void changeChordLabels(){
	for(int i=0; i < chords.length; i++){
	    jChordButtons[i].setText((String)jChordRoot.getSelectedItem()+chords[i]);
	}
    }

    public static void changeLiveTuning() {
	if(midichannels == null){
	    return;
	}
	// set the program
	int program = jProgram.getSelectedIndex();

	// set the tuning
	int pitchshift[] = {0,0,0,0,0,0,0,0,0,0,0,0};


	// load the pitch shift values for each channel
	try{
	    pitchshift = loadpitchshifts((String)jTunings.getSelectedItem(),2,jTuningAdvancedPanel.getRootNote(), jTuningAdvancedPanel.getFrequency());
	} catch (IOException e){}
	
	int rootnote = jNotes.getSelectedIndex();
	for(int nchannel=0; nchannel<12; nchannel++){
	    int fromroot = nchannel - rootnote;
	    if(fromroot < 0){
		fromroot = fromroot + 12;
	    }
	    int realchannel=nchannel;
	    if(nchannel > 8){
		realchannel = realchannel+1;
	    }
	    
	   midichannels[realchannel].programChange(program);
	   midichannels[realchannel].setPitchBend(pitchshift[fromroot]);
	}
	
	/////////////////////
	if(!(theSequencer == null)){
	    // a call to seSequencerTickPosition will automatically write
	    // the changed data where it will be immediately processed
	    // by the synth
	    if(theSequencer.isRunning()){
		long pos = theSequencer.getTickPosition();
		startSequence(pos);
	    }
	    //setSequencerTickPosition(pos);
	}
	/////////////
    }

    private static class KeyboardPanel extends JPanel implements MouseListener {
	private static final int keyH = 100;
	private static final int blackH = 75;
	private static final int margin = 10;
	private int[] whitekeystartx, whitekeyendx, whitekeynotes, blackkeystartx, blackkeyendx, blackkeynotes;
	private int[] whiteblacknum;
	private int nwhitekeys, nblackkeys;
	private static Boolean[] keyon;

	// these are the keys on the keyboard that can be used to play notes on the virtual musical keyboard
	public static Character[] upperwhitekeys = {'q','w','e','r','t','y','u','i','o','p'};
	public static Character[] upperblackkeys = {'1','2','3','4','5','6','7','8','9','0','-'};
	public static Character[] lowerwhitekeys = {'z','x','c','v','b','n','m'};
	public static Character[] lowerblackkeys = {'a','s','d','f','g','h','j','k'};
	// these are the lowest note you can play using the upper and lower rows of keys on your computer
	public static final int upperkeyboardstartnote = 60;
	public static final int lowerkeyboardstartnote = 48;
	// arrays to store which note goes with each key
	public static Integer[] upperwhitekeynotes, upperblackkeynotes, lowerwhitekeynotes, lowerblackkeynotes;
	public static Character[] allkeychars;
	public static Integer[] allkeynotes;
	private static int currentnote;

	KeyboardPanel(){
	    super();
	    nwhitekeys = 0;
	    nblackkeys = 0;
	    for(int i = lownote; i < highnote+1; i++){
		if(iswhitekey(i))
		    nwhitekeys += 1;
		else
		    nblackkeys += 1;
	    }
	    whitekeystartx = new int[nwhitekeys];
	    whitekeyendx = new int[nwhitekeys];
	    whitekeynotes = new int[nwhitekeys];
	    blackkeystartx = new int[nblackkeys];
	    blackkeyendx = new int[nblackkeys];
	    blackkeynotes = new int[nblackkeys];
	    keyon = new Boolean[highnote-lownote+1];
	    whiteblacknum = new int[highnote-lownote+1];

	    upperwhitekeynotes = new Integer[upperwhitekeys.length];
	    upperblackkeynotes = new Integer[upperblackkeys.length];
	    lowerwhitekeynotes = new Integer[lowerwhitekeys.length];
	    lowerblackkeynotes = new Integer[lowerblackkeys.length];

	    Arrays.fill(upperwhitekeynotes,999);
	    Arrays.fill(upperblackkeynotes,999);
	    Arrays.fill(lowerwhitekeynotes,999);
	    Arrays.fill(lowerblackkeynotes,999);
	    int ikey = 0;
	    int currentnote = upperkeyboardstartnote;
	    while(ikey < upperblackkeys.length){
		if(iswhitekey(currentnote)){
		    if(ikey >= upperwhitekeys.length){
			break;
		    }
		    upperwhitekeynotes[ikey] = currentnote;
		    ikey += 1;
		    currentnote += 1;
		}
		else{
		    upperblackkeynotes[ikey] = currentnote;
		    currentnote += 1;
		}
	    }
	    ikey = 0;
	    currentnote = lowerkeyboardstartnote;
	    while(ikey < lowerblackkeys.length){
		if(iswhitekey(currentnote)){
		    if(ikey >= lowerwhitekeys.length){
			break;
		    }
		    lowerwhitekeynotes[ikey] = currentnote;
		    ikey += 1;
		    currentnote += 1;
		}
		else{
		    lowerblackkeynotes[ikey] = currentnote;
		    currentnote += 1;
		}
	    }

	    for(int i=0; i < highnote-lownote+1; i++){
		keyon[i] = false;
	    }
	    ArrayList<Character> charlist = new ArrayList<Character>();
	    charlist.addAll(Arrays.asList(upperwhitekeys));
	    charlist.addAll(Arrays.asList(upperblackkeys));
	    charlist.addAll(Arrays.asList(lowerwhitekeys));
	    charlist.addAll(Arrays.asList(lowerblackkeys));
	    allkeychars = new Character[charlist.size()];
	    allkeychars = charlist.toArray(allkeychars);

	    ArrayList<Integer> intlist = new ArrayList<Integer>();
	    intlist.addAll(Arrays.asList(upperwhitekeynotes));
	    intlist.addAll(Arrays.asList(upperblackkeynotes));
	    intlist.addAll(Arrays.asList(lowerwhitekeynotes));
	    intlist.addAll(Arrays.asList(lowerblackkeynotes));
	    allkeynotes = new Integer[intlist.size()];
	    allkeynotes = intlist.toArray(allkeynotes);

	    addMouseListener(this);
	}

	private Boolean isNoteOn(int note){
	    Boolean i = keyon[note-lownote];
	    return(i);
	}

	public void upHalfStep(){
	    upHalfSteps(1);
	}

	public void upHalfSteps(int n){	   
	    for(int i = highnote; i >= lownote+n ; i--){
		if(isNoteOn(i))
		    stopNote(i);
		if(isNoteOn(i-n)){
		    playNote(i);
		}
	    }
	    for(int i = lownote+n-1; i >= lownote; i--){
		stopNote(i);
	    }
	}

	public void downHalfStep(){
	    downHalfSteps(1);
	}

	public void downHalfSteps(int n){
	    for(int i = lownote; i <= highnote-n; i++){
		if(isNoteOn(i))
		    stopNote(i);
		if(isNoteOn(i+n)){
		    playNote(i);
		}
	    }
	    for(int i = highnote-n+1; i <= highnote; i++){
		stopNote(i);
	    }
	}

	public void allOff(){
	    for(int i = 0; i < 16; i++){
		midichannels[i].allNotesOff();
	    }
	    for(int i=0; i < highnote-lownote+1; i++){
		keyon[i] = false;
	    }
	    drawKeyboard(this.getGraphics());
	}
	
	private int[] noteDotPos(int note){
	    int rectx, recty;
	    int i = whiteblacknum[note-lownote];
	    if(iswhitekey(note)){
		rectx = (whitekeystartx[i]+whitekeyendx[i])/2;
		recty = keyH-17;		
	    }
	    else{
		rectx = (blackkeystartx[i]+blackkeyendx[i])/2;
		recty = blackH-17;
	    }
	    return(new int[]{rectx,recty});
	}

	private int[] noteSeqDotPos(int note){
	    int rectx, recty;
	    int i = whiteblacknum[note-lownote];
	    if(iswhitekey(note)){
		rectx = (whitekeystartx[i]+whitekeyendx[i])/2;
		recty = keyH-7;		
	    }
	    else{
		rectx = (blackkeystartx[i]+blackkeyendx[i])/2;
		recty = blackH-7;
	    }
	    return(new int[]{rectx,recty});
	}
	
	private void drawSquare(int note,Graphics g){
	    Graphics2D g2d = (Graphics2D)g;
	    if(g2d == null){
		g2d = (Graphics2D) this.getGraphics();
	    }
	    int[] rect = noteDotPos(note);
	    g2d.setColor(Color.BLUE);
	    g2d.fillRect(margin/2+rect[0]-4,margin/2+rect[1]-4,8,8);
	}

	private void clearSquare(int note){
	    Graphics2D g2d = (Graphics2D) this.getGraphics();
	    int[] rect = noteDotPos(note);
	    if(iswhitekey(note)){
		g2d.setColor(Color.WHITE);
	    }
	    else{
		g2d.setColor(Color.BLACK);
	    }
	    g2d.fillRect(margin/2+rect[0]-5,margin/2+rect[1]-5,10,10);
	}

	private void drawSeqSquare(int note,Graphics g){
	    Graphics2D g2d = (Graphics2D)g;
	    if(g2d == null){
		g2d = (Graphics2D) this.getGraphics();
	    }
	    int[] rect = noteSeqDotPos(note);
	    g2d.setColor(Color.RED);
	    g2d.fillRect(margin/2+rect[0]-4,margin/2+rect[1]-4,8,8);
	}

	private void clearSeqSquare(int note){
	    Graphics2D g2d = (Graphics2D) this.getGraphics();
	    int[] rect = noteSeqDotPos(note);
	    if(iswhitekey(note)){
		g2d.setColor(Color.WHITE);
	    }
	    else{
		g2d.setColor(Color.BLACK);
	    }
	    g2d.fillRect(margin/2+rect[0]-5,margin/2+rect[1]-5,10,10);
	}
       

	public void playNote(int note){
	    if((note < lownote)||(note > highnote))
		return;
	    int thechannel = note%12;
	    if(thechannel > 8){
		thechannel += 1;
	    }
	    if(keyon[note-lownote]==false){
		midichannels[thechannel].noteOn(note,127);
		keyon[note-lownote]=true;	    
	    }
	    drawSquare(note,null);
	}

	public void stopNote(int note){
	    if((note < lownote)||(note > highnote))
		return;
	    int thechannel = note%12;
	    if(thechannel > 8){
		thechannel += 1;
	    }
	    midichannels[thechannel].noteOff(note);
	    keyon[note-lownote]=false;
	    clearSquare(note);
	}

	public void toggleNote(int note){
	    if((note < lownote)||(note > highnote))
		return;
	    if(keyon[note-lownote]){
		stopNote(note);
	    }
	    else{
		playNote(note);
	    }	    
	}

	public void mousePressed(MouseEvent e){
	    kbPanel.requestFocus();
	    int x = e.getX();
	    int y = e.getY();
	    currentnote = 0;
	    if(y < blackH){
		for(int i = 0; i < nblackkeys; i++){
		    if((blackkeystartx[i] < x)&&(blackkeyendx[i] >= x)){
			currentnote = blackkeynotes[i];
			break;
		    }
		}
	    }
	    if(currentnote == 0){
		for(int i = 0; i < nwhitekeys; i++){
		    if((whitekeystartx[i] < x)&&(whitekeyendx[i] >= x)){
			currentnote = whitekeynotes[i];
		    }
		}
	    }
	    if(sustain){
		toggleNote(currentnote);
	    }
	    else{
		playNote(currentnote);
	    }
	}

	public void mouseReleased(MouseEvent e){
	    if(!sustain)
		stopNote(currentnote);
	}
	public void mouseClicked(MouseEvent e){
	}
	public void mouseEntered(MouseEvent e){
	}
	public void mouseExited(MouseEvent e){
	}

	
	public void paintComponent(Graphics g){
	    super.paintComponent(g);
	    drawKeyboard(g);
	}
	

	public void drawKeyboard(Graphics g){
	    Graphics2D g2d = (Graphics2D) g;
	    int keyboardW = frame.getSize().width-margin;
	    int whitewidth, whitestart;
	    if(iswhitekey(lownote)&&iswhitekey(highnote)){
		whitewidth = keyboardW;
		whitestart = 0;
	    }
	    else if(iswhitekey(lownote)){
		whitewidth = (keyboardW*2*nwhitekeys)/(nwhitekeys*2+1);
		whitestart = 0;
	    }
	    else if(iswhitekey(highnote)){
		whitewidth = (keyboardW*2*nwhitekeys)/(nwhitekeys*2+1);
		whitestart = keyboardW-whitewidth;
	    }
	    else{
		whitewidth = (keyboardW*2*nwhitekeys)/(nwhitekeys*2+2);
		whitestart = (keyboardW-whitewidth)/2;
	    }
	    int keywidth = whitewidth/nwhitekeys;
	    int blackkeywidth = (int)(keywidth*0.7);
	    int whitekeyheight = 100;
	    int blackkeyheight = 75;
	    g2d.setColor(Color.WHITE);
	    g2d.fillRect(margin/2+whitestart,margin/2,keywidth*nwhitekeys,keyH);
	    g2d.setColor(Color.BLACK);
	    // set up position of keys
	    int thiswhite = 0;
	    int nwhite = 0;
	    int nblack = 0;
	    for(int i = 0; i < highnote-lownote+1; i++){
		if(iswhitekey(lownote+i)){
		    whitekeystartx[nwhite] = whitestart+thiswhite*keywidth;
		    whitekeyendx[nwhite] = whitestart+(thiswhite+1)*keywidth;
		    whitekeynotes[nwhite] = lownote+i;
		    whiteblacknum[i] = nwhite;
		    nwhite += 1;
		    thiswhite += 1;
		}
		else{
		    blackkeystartx[nblack] = whitestart+thiswhite*keywidth-blackkeywidth/2;
		    blackkeyendx[nblack] = whitestart+thiswhite*keywidth+blackkeywidth/2;
		    blackkeynotes[nblack] = lownote + i;
		    whiteblacknum[i] = nblack;
		    nblack += 1;
		}
	    }
	    // draw black keys first
	    for(int i = 0; i < nblackkeys; i++){
		g2d.fillRect(margin/2+blackkeystartx[i],margin/2,blackkeywidth,blackkeyheight);
		g2d.setColor(Color.WHITE);
		g2d.drawRect(margin/2+blackkeystartx[i],margin/2,blackkeywidth,blackkeyheight);
		g2d.setColor(Color.BLACK);
	    }
	    // now white keys
	    for(int i = 0; i < nwhitekeys; i++){
		g2d.drawRect(margin/2+whitekeystartx[i],margin/2,keywidth,whitekeyheight);
	    }

	    // place squares indicating which notes are on
	    for(int note = lownote; note <= highnote; note++){
		if(keyon[note-lownote]){
		    drawSquare(note,g);
		}
	    }

	    // draw letters telling you which notes they play
	    drawKeyLabels(g2d, false, upperwhitekeys, upperwhitekeynotes, whitekeynotes, whitekeystartx, keywidth, margin);
	    drawKeyLabels(g2d, true, upperblackkeys, upperblackkeynotes, blackkeynotes, blackkeystartx, blackkeywidth, margin);
	    drawKeyLabels(g2d, false, lowerwhitekeys, lowerwhitekeynotes, whitekeynotes, whitekeystartx, keywidth, margin);
	    drawKeyLabels(g2d, true, lowerblackkeys, lowerblackkeynotes, blackkeynotes, blackkeystartx, blackkeywidth, margin);


       	}

	// draw the labels which show which keys to press to play different notes
	private void drawKeyLabels(Graphics2D g2d, Boolean isBlack, Character[] compkeychars, Integer[] compkeynotes, int[] muskeynotes, int[] muskeyloc, int keywidth, int margin){ 
	    Font thefont = new Font("Dialog", Font.PLAIN, 10);
	    g2d.setFont(thefont);
	    FontMetrics fmetrics = g2d.getFontMetrics();
	    int vloc = 20;
	    if(isBlack){
		g2d.setColor(Color.WHITE);
		vloc = 15;
	    }
	    else{
		g2d.setColor(Color.BLACK);
	    }
	    for(int i = 0; i < compkeychars.length; i++){
		if(compkeynotes[i] < 999){
		    int j;
		    for(j = 0; j < muskeynotes.length; j++){
			if(muskeynotes[j] == compkeynotes[i]){
			    break;
			}
		    }
		    Rectangle strBounds = fmetrics.getStringBounds(String.valueOf(compkeychars[i]),g2d).getBounds();
		    g2d.drawString(String.valueOf(compkeychars[i]),(margin/2)+muskeyloc[j]+(keywidth/2)-(strBounds.width/2),vloc);
		}
	    }

	}

	public Dimension getPreferredSize(){
	    return new Dimension(frame.getSize().width-margin,keyH+margin);
	}
	public Dimension getMinimumSize(){
	    return new Dimension(frame.getSize().width-margin,keyH+margin);
	}
    }

    private static Boolean iswhitekey(int note){
	int mn = note%12;
	if( (mn == 0) || (mn == 2) || (mn == 4) || (mn == 5) || (mn == 7) || (mn == 9) || (mn == 11))
	    return(true);
	return(false);
    }

    public static ArrayList<String> gettuninglist() throws IOException {
	// reads tuning scheme titles from file
	ArrayList<String> tuninglist = new ArrayList<String>();
       
	try{
	    BufferedReader in = new BufferedReader(new FileReader(tuningfilename));
	    String line;
	    while((line=in.readLine()) != null) {
		line = line.trim();
		if(line.length()>0){
		    if(!line.startsWith("#")){
			tuninglist.add(line);
			for(int i = 0; i < 12; i++){
			    line=in.readLine();
			}
		    }
		}
	    }
	    in.close();
	} catch (IOException e) {
	    displayerror("Problem reading tunings file "+tuningfilename);
	}
	return(tuninglist);
    }

    public static int[] loadpitchshifts(String tuningscheme, double bendrange, int tuningnote, Double tuningfreq) throws IOException {
	// read tunings file and calculate correct pitch shifts for selected tuning scheme
	// bendrange is in semitones - ie, if bend goes +/- 2 semitones, bendrange will be 2
	
	int pitchshift[] = {0,0,0,0,0,0,0,0,0,0,0,0};
	double pitchratios[] = {0,0,0,0,0,0,0,0,0,0,0,0};

	try{
	    BufferedReader in = new BufferedReader(new FileReader(tuningfilename));
	    String line;
	    while((line=in.readLine()) != null) {
		line = line.trim();
		if(line.equals(tuningscheme)){
		    for(int i=0; i<12; i++){
			line = in.readLine();
			line = line.trim();
			pitchratios[i] = Double.parseDouble(line);
		    }
		    break;
		}
	    }
	    if(line == null){
		displayerror("Tuning scheme "+tuningscheme+" not found");
		haderror = true;
	    }
	} catch (IOException e) {
	    displayerror("Problem reading tunings file");
	    haderror = true;
	}   

	// midi specs use a numerical value from (0 to 16383) with 8192 meaning no bend
	
	double standardroot = 440.0*Math.pow(2.0,((double)(tuningnote-9))/12.0);
	double semisoff = 12*Math.log(tuningfreq/standardroot)/Math.log(2.0);
	int offset = (int)((8191.0*semisoff)/bendrange);
	Boolean messagesent = false;

	for(int nnote=0; nnote < 12; nnote++){
	    // convert frequency ratio from file into a midi pitch shift parameter
	    pitchshift[nnote] = 8192+(int)(8191.0*((12.0*Math.log(pitchratios[nnote])/Math.log(2.0))-nnote)/bendrange);
	    pitchshift[nnote] += offset;
	    if((pitchshift[nnote] < 0)||(pitchshift[nnote] > 16383)){
		pitchshift[nnote] = 0;
		if(!messagesent){
		    displayerror("A pitch bend is out of range!  Your tuning is too extreme for this method.  Try using a tuning root closer to A440 or a tuning scheme closer to equal temperament.  Outputing garbage until you fix this.");
		    messagesent = true;
		}
	    }
	}
	return(pitchshift);
    }

    ///////////////////////////////////////////////////////////////////////////////
    //////// Generate re-tuned sequence ////////////////

    public static Sequence retunedSequence(Sequence midiIn, int rootnote, String temperamentstring, double maxpitchbend, Boolean writemaxpitchbend, int selectProgram, Boolean addmetas, int tuningroot, Double tuningfreq, int transposeamt, long tickpos)  throws MidiUnavailableException, InvalidMidiDataException, IOException {

	// note - tickpos is where to put the "beginning of file" commands.
	// tickpos is normally zero - except when you jump to a point in the song,
	// JAVA seems to reset controllers.  So we'll set the controllers
	// right where we are jumping to.

	int pitchshift[] = {0,0,0,0,0,0,0,0,0,0,0,0};

	// load the pitch shift values for each channel
	try{
	    pitchshift = loadpitchshifts(temperamentstring,maxpitchbend, tuningroot, tuningfreq);
	} catch (IOException e){}
	
	if(haderror){
	    haderror = false;
	    return(null);
	}


	// get the tracks from the midi file
	Track[] tracks = midiIn.getTracks();
	if(tracks.length == 0){
	    displayerror("Input file does not appear to contain any tracks!");
	    return(null);
	}
	
	Sequence newMidi = null;
	try{
	    newMidi = new Sequence(midiIn.getDivisionType(),midiIn.getResolution());
	} catch (Exception e){
	    return(null);
	}
	
	// this will be used to make midi events on new midi sequenc
	ShortMessage sm = null;

	// this tracks if a program (instrument) has been set
	Boolean progset = false;
	
	// go through all of the tracks in the input file
	Boolean senttransposemessage = false;
	for(int ntrack = 0; ntrack < tracks.length; ntrack++){

	    // Make a new track in the new midi sequence where we can store events from the corresponding track in the input file
	    Track thisTrack = newMidi.createTrack();

	    // put selected program in
	    

	    // put pitch bends and program change onto every channel in this track to achieve correct tuning
	    int realchannel=0;
	    int fromroot=0;
	    int nchannel;
	    for(nchannel = 0; nchannel < 12; nchannel++){
		// midi channel 10 is reserved for percussion - but the midi "parlance" numbers the channels from 1, while the file
		// format numbers them from 0.  So in this code the percussion channel is really 9.  We want to avoid that one, so
		// for any channel greater than 8, we will go up a channel (thereby using channels 0,1,2,3,4,5,6,7,8,10,11)
		realchannel=nchannel;
		if(nchannel > 8){
		    realchannel = realchannel+1;
		}
		// set program
		if(selectProgram >= 0){
		    sm = new ShortMessage();
		    sm.setMessage(ShortMessage.PROGRAM_CHANGE, realchannel,selectProgram,0 );
		    thisTrack.add(new MidiEvent(sm,tickpos));			
		    progset = true;
		}


		// We're going to assume that channel 0 has all of the c's, channel 1 has all of the c#'s, etc.
		// But our array of pitch shifts start at the root.  If the root we selected isn't c, then we don't
		// want to use pitchshift[0] for channel 0.  The variable "fromroot" tells us how many half steps 
		// the notes on the current channel are from the root note, so we can use the correct pitch shift.
		fromroot = nchannel - rootnote;
		if(fromroot < 0){
		    fromroot = fromroot + 12;
		}
		// Midi pitch shifts are written in two 7-bit bytes.  The code below calculates those two bytes from the pitch shift number
		int pitchshiftlsb = pitchshift[fromroot] & 0x7F;
		int pitchshiftmsb = (pitchshift[fromroot]>>7) & 0x7F;
		// Write the correct pitch shift value to the midi channel
		if(writemaxpitchbend){
		    // Set the pitch bend range
		    sm = new ShortMessage();
		    sm.setMessage(ShortMessage.CONTROL_CHANGE, realchannel, 101,0);
		    thisTrack.add(new MidiEvent(sm,tickpos));
		    sm = new ShortMessage();
		    sm.setMessage(ShortMessage.CONTROL_CHANGE, realchannel, 100,0);
		    thisTrack.add(new MidiEvent(sm,tickpos));
		    sm = new ShortMessage();
		    sm.setMessage(ShortMessage.CONTROL_CHANGE, realchannel, 6,(int)maxpitchbend);
		    thisTrack.add(new MidiEvent(sm,tickpos));
		    sm = new ShortMessage();
		    sm.setMessage(ShortMessage.CONTROL_CHANGE, realchannel, 38,0);
		    thisTrack.add(new MidiEvent(sm,tickpos));
		    // reset controllers 101 and 100 so that future writes to controller 6 don't change pitch bend range
		    sm = new ShortMessage();		    
		    sm.setMessage(ShortMessage.CONTROL_CHANGE, realchannel, 100,127);
		    thisTrack.add(new MidiEvent(sm,tickpos));
		    sm = new ShortMessage();
		    sm.setMessage(ShortMessage.CONTROL_CHANGE, realchannel, 101,127);
		    thisTrack.add(new MidiEvent(sm,tickpos));
		}
		sm = new ShortMessage();
		sm.setMessage(ShortMessage.PITCH_BEND, realchannel, pitchshiftlsb, pitchshiftmsb);
		thisTrack.add(new MidiEvent(sm,tickpos));	
	    }
	    
	    // go through each event in the current midi track in the input file, adjust the event, and put it into the new track
	    for(int nevent = 0; nevent < tracks[ntrack].size(); nevent++){	   
		MidiEvent thisevent = tracks[ntrack].get(nevent);
		MidiMessage message = thisevent.getMessage();
                int statusInt = (int)message.getStatus();
                int channel = (statusInt & 0x000F)+1;
		int note = 0;

		// Each event has an event type.  What we do with it depends on what type of event it is.
		int eventtype = (statusInt & 0x00F0)>>4; 
		int newchannel = 0;
                switch (eventtype) {
		    // First deal with events which only affect one note
		    // these are the midi events which only affect one note
		    // hex   midi event        param 1              param 2
		    // 0x8 = note off          note number          velocity
		    // 0x9 = note on           note number          velocity
		    // 0xA = note aftertouch   note number          aftertouch value
		    
		case 0x8:
		    // note off       
		    note = (int)message.getMessage()[1] & 0xFF;
		    note = note + transposeamt;
		    if((note < 0)||(note > 127)){
			if(!senttransposemessage){
			    displayerror("Transposing this piece puts notes out if midi range.  Generating garbage until you use a smaller transpose amount.");
			    senttransposemessage = true;
			}
			note = 0;
		    }
		    sm = new ShortMessage();
		    // find the new channel based on which note is being turned off, stored in byte 1 of the message
		    // uses modulo 12, because we don't care what it's octave is
		    newchannel = ((int)message.getMessage()[1] & 0xFF) % 12;
		    // move channels 10 and above to avoid using channel 10, which is reserved for percussion
		    // note that the channels are colloquially labelled 1-16, but the actual values in the midi file go from 0-15
		    // so the channel we are avoiding, channel 10, is actually channel 9
		    if(newchannel > 8){
			newchannel = newchannel + 1;
		    }
		    // add adjusted event to new track
		    sm.setMessage(ShortMessage.NOTE_OFF, newchannel, ((int)message.getMessage()[1] & 0xFF), ((int)message.getMessage()[2] & 0xFF));
		    thisTrack.add(new MidiEvent(sm,thisevent.getTick()));			
		    if(addmetas){
			String ms = "off:"+Integer.toString(note);
			byte[] ba = ms.getBytes();
			MetaMessage mm = new MetaMessage(metaCuePoint,ba,ba.length);
			thisTrack.add(new MidiEvent(mm,thisevent.getTick()));
		    }
		    break;
		case 0x9:
		    // note on
		    // see notes for note off above
		    sm = new ShortMessage();
		    note = ((int)message.getMessage()[1] & 0Xff);
		    note = note + transposeamt;
		    if((note < 0)||(note > 127)){
			if(!senttransposemessage){
			    displayerror("Transposing this piece puts notes out if midi range.  Generating garbage until you use a smaller transpose amount.");
			    senttransposemessage = true;
			}
			note = 0;
		    }

		    newchannel = note % 12;
		    if(newchannel > 8){
			newchannel = newchannel + 1;
		    }
		    sm.setMessage(ShortMessage.NOTE_ON, newchannel, note, ((int)message.getMessage()[2] & 0xFF));
		    thisTrack.add(new MidiEvent(sm,thisevent.getTick()));
		    if(addmetas){
			String ms;
			if( ((int)message.getMessage()[2] & 0xFF) == 0)
			    ms = "off:"+Integer.toString(note);
			else
			    ms = "on:"+Integer.toString(note);
			byte[] ba = ms.getBytes();
			MetaMessage mm = new MetaMessage(metaCuePoint,ba,ba.length);
			thisTrack.add(new MidiEvent(mm,thisevent.getTick()));
		    }
		    break;
		case 0xA:		      
		    // note aftertouch
		    // see notes for note off above
		    sm = new ShortMessage();
		    note = ((int)message.getMessage()[1] & 0Xff);
		    note = note + transposeamt;
		    if((note < 0)||(note > 127)){
			if(!senttransposemessage){
			    displayerror("Transposing this piece puts notes out if midi range.  Generating garbage until you use a smaller transpose amount.");
			    senttransposemessage = true;
			}
			note = 0;
		    }
		    newchannel = note % 12;
		    if(newchannel > 8){
			newchannel = newchannel + 1;
		    }
		    sm = new ShortMessage();
		    sm.setMessage(ShortMessage.POLY_PRESSURE, newchannel, note, ((int)message.getMessage()[2] & 0xFF));
		    thisTrack.add(new MidiEvent(sm,thisevent.getTick()));
		    break;
		    
		    // Now we'll deal with events that affect the entire channel.  First we need to stop any pitch bend from being copied over
		    // since that will mess up our tuning.
		case 0xE:
		    // pitch bend - we won't copy this one over
		    break;
		    
		    // Now we'll deal with other channel-wide events
		    // hex   midi event          param 1              param 2
		    // 0xB = controller change   controller           value
		    // 0xC = program change      new program          ---
		    // 0xD = channel pressure    new pressure         ---
		    
		    // since we're moving notes into different channels, it's probably best to 
		    // duplicate these events onto all of the channels used (0,1,2,3,4,5,6,7,8,10,11,12).
		    
		    
		case 0xC:
		    if(progset){
			break;
		    }
		    if(selectProgram == progUseFirst){
			progset = true;
		    }
		case 0xB:
		case 0xD:
		    // copy event to all channels
		    for(nchannel = 0; nchannel < 12; nchannel++){
			realchannel = nchannel;
			if(realchannel > 8){
			    realchannel++;
			}
			sm = new ShortMessage();
			if(message.getMessage().length < 3){
			    sm.setMessage(eventtype<<4, realchannel, ((int)message.getMessage()[1] & 0xFF), 0);
			}
			else{
			    sm.setMessage(eventtype<<4, realchannel, ((int)message.getMessage()[1] & 0xFF), ((int)message.getMessage()[2] & 0xFF));
			}
			thisTrack.add(new MidiEvent(sm,thisevent.getTick()));			
		    }
		    break;
		    
		    // Anything else must not be channel specific, so we'll just copy it over
		default:
		    thisTrack.add(thisevent);
		    break;
		}
	    }	
	}
	return(newMidi);
    }

    public static void makethefile(String infile, String outfile, int rootnote, String temperamentstring, double maxpitchbend, Boolean writemaxpitchbend, int selectProgram, int tuningroot, double tuningfrequency, int transposeamt)  throws MidiUnavailableException, InvalidMidiDataException, IOException {
	// create and save tuned midi file
	// infile is the midi file to read in, outfile is the path for the modified file to be saved, rootnote is the note to base the tuning scheme on, temperamentstring is a string that tells what tuning scheme to use, maxpitchbend is the number of semitones the target midi synth can bend a note

	// write a string saying what's happening here
	// System.out.println(infile+"   "+outfile+"   "+rootnote+"   "+temperamentstring+"   "+maxpitchbend+"   "+writemaxpitchbend);

	// open up the input midi file
        Sequence midiIn = null;
        try {
            midiIn = MidiSystem.getSequence(new File(infile));
        } catch (Exception e) {
            displayerror("Error opening midi file "+infile+" for reading");
	    return;
        }


	// make a new midi sequence to store the modified midi stream
	Sequence newMidi = retunedSequence(midiIn,rootnote,temperamentstring,maxpitchbend,writemaxpitchbend,selectProgram,false,tuningroot,tuningfrequency, transposeamt,0);
	if(newMidi == null){
	    displayerror("Error generating new midi sequence");
	    return;
	}

	// Now write the new midi file
	try{
	    MidiSystem.write(newMidi,1,new File(outfile));
	} catch (IOException e) {
	    displayerror("Problem writing to file "+outfile);
	    return;
	}
	displaymessage("Done!  New midi file written to "+outfile);
    }
    

    public static void printUsageAndExit() {
	System.out.println(description+"\n\n"+usage);
	System.exit(1);
    }
    
    public static void printHelpAndExit() {
	String commandlinehelp = readStringFromJar("CommandlineUsage.txt");

	System.out.println(description+"\n\n"+commandlinehelp);
	System.exit(0);
    }

    public static int getComponentIndex(Component component, Container container){
	Component[] components = container.getComponents();
	for(int i=0; i < components.length; i++){
	    if(components[i] == component){
		return(i);
	    }
	}
	return(-1);
    }

    // loads sequence, sets up tuning, and starts playing it at the given location
    public static void startSequence(long ticks){
	jPlay.setText(stopstring);
	jPause.setText(pausestring);
	jPause.setEnabled(true);				
	try{
	    theSequencer.stop();
	    theSequencer.close();
	}
	catch (Exception ea){}
	try{
	    int fileprogram = progChangeCodes[jChooseFileProgram.getSelectedIndex()];
	    if(fileprogram == progUseSelected){
		fileprogram = jProgram.getSelectedIndex();
	    }

	    theSequence = retunedSequence(midiIn,jNotes.getSelectedIndex(), jTunings.getSelectedItem().toString(), 2.0, false,fileprogram,true,jTuningAdvancedPanel.getRootNote(),jTuningAdvancedPanel.getFrequency(),(Integer)jTransposeAmount.getSelectedItem(),ticks+1);
	}
	catch (Exception ea){return;}
	try{
	    theSequencer.open();
	    theSequencer.addMetaEventListener(new MetaEventListener(){
		    public void meta(MetaMessage msg){
			if (msg.getType() == metaEndTrack ){ 
			    endSequence(true);
			}
			if(msg.getType() == metaCuePoint){
			    byte[] bmsg = msg.getData();
			    String smsg = new String(bmsg);
			    if(smsg.startsWith("on:")){
				int note = Integer.parseInt(smsg.substring(3));
				kbPanel.drawSeqSquare(note,null);
			    }
			    if(smsg.startsWith("off:")){
				int note = Integer.parseInt(smsg.substring(4));
				kbPanel.clearSeqSquare(note);
			    }
			}
		    }
		});
	    theSequencer.setSequence(theSequence);
	    //setAllComponentsEnabled(jTuningSchemePanel,false);
	    jMidiProgress.setMaximum((int)theSequencer.getMicrosecondLength()/10000);
	    jMidiProgress.setValue((int)(ticks/10000));
	    progressTimer.start();
	    theSequencer.setTickPosition(ticks);
	    theSequencer.start();
	}
	catch (Exception ea){
	    //setAllComponentsEnabled(jTuningSchemePanel,true);
	}
    }

    public static void endSequence(Boolean resetprogress){
	theSequencer.stop();
	theSequencer.close();
	jPlay.setText(playstring);
	jPause.setText(pausestring);
	if(resetprogress){
	    jMidiProgress.setValue(0);
	}
	jPause.setEnabled(false);
	//setAllComponentsEnabled(jTuningSchemePanel,true);
	kbPanel.repaint();
    }

    private static String readStringFromJar(String filename){
	InputStream jarinput = ModMIDITuning.class.getResourceAsStream(filename);
	StringBuilder sb = new StringBuilder();
	try{
	    BufferedReader br = new BufferedReader(new InputStreamReader(jarinput));
	    String line = br.readLine();
	    while(line != null){
		sb.append(line+"\n");
		line = br.readLine();
	    }
	    br.close();
	} catch (Exception e) {}
	return(sb.toString());
    }


    private static String getSuggestedFilename(String infilename, String tuningmethod, int tuningroot, int tuningref, double tuningfreq){
	// builds a suggested filename to save a retuned version of the midi file infilename
	// tuningmethod is the string that describes the tuning method
	// tuningroot is the root note of the tuning method.  C is 0, C# is 1, etc.
	// tuningref is which note is set to a fixed frequency - for example, for A440, it's "A."  C is 0, etc.
	// tuningfreq is the frequency of the tuningref note.  For A440, it would be 440.0, etc.

	String suggestedfilename = infilename;
	// find where the extention .mid starts
	int lastdot = suggestedfilename.lastIndexOf('.');
	if(lastdot >=0){
	    suggestedfilename = suggestedfilename.substring(0,lastdot);
	}		    
	// add info about tuning method and root, tuning frequency
	suggestedfilename += "_"+tuningmethod+notes[tuningroot]+"_"+notes[tuningref]+Integer.toString((int)Math.round(tuningfreq));
	suggestedfilename = suggestedfilename+".mid";
	return(suggestedfilename);
    }
    
    
}
